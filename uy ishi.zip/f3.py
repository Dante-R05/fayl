import os, math
os.system("cls")

sonlar=[1.2, 2.4, 5.6, 8.1, 4.2, 3.1]

natija=list(map(int, sonlar))
print(natija)