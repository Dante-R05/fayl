import os, math
os.system("cls")



sonlar=[1.2, 3.4, 2.4, 7.2, 5.4, 8.5, 4.1]

natija=list(map(math.ceil, sonlar))

print(natija)